package com.example.hp.flip;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterViewFlipper;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
        private AdapterViewFlipper AVF;
        int[] image={R.drawable.imone,R.drawable.imtwo,R.drawable.imthree,R.drawable.imfour};
        String[] names={"Image1","Image2","Image3","Image4"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AVF=(AdapterViewFlipper)findViewById(R.id.AVF);
        CustomAdapter customAdapter=new CustomAdapter(getApplicationContext(),names,image);
        AVF.setAdapter(customAdapter);
        //AVF.setFlipInterval(2000);
      //  AVF.setAutoStart(true);
        AVF.setOnTouchListener(new OnSwipeTouchListener(MainActivity.this) {

            public void onSwipeRight() {
                //Toast.makeText(MainActivity.this, "right", Toast.LENGTH_SHORT).show();
                AVF.showPrevious();
            }
            public void onSwipeLeft() {
                //Toast.makeText(MainActivity.this, "left", Toast.LENGTH_SHORT).show();

                AVF.showNext();
            }

        });


    }
}
