package Model;



public class ListItem {

    private int img;
    private String description;
    public ListItem(int img, String description) {
        this.img=img;
        this.description = description;
    }
    public int getImg() {
        return img;
    }

    public void setName(int img) {
        this.img = img;
    }

    public void setDesc(String description)
    {
        this.description = description;
    }

    public String getDesc()
    {
        return description;
    }


}
