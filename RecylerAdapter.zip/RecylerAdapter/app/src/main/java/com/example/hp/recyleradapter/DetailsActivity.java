package com.example.hp.recyleradapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {
    private ImageView img;
    private TextView desc;
    private Bundle extras;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        extras=getIntent().getExtras();
        img=(ImageView) findViewById(R.id.dimg);
        desc=(TextView) findViewById(R.id.desc);
        if(extras !=null)
        {
            img.setImageResource(extras.getInt("img"));
            desc.setText(extras.getString("description"));
        }
    }
}
