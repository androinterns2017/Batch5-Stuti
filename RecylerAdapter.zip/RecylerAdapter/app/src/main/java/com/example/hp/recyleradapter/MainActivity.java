package com.example.hp.recyleradapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import Adapter.MyAdapter;
import Model.ListItem;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recylerView;
    private RecyclerView.Adapter adapter;
    private List<ListItem> listItems = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recylerView=(RecyclerView)findViewById(R.id.recyclerview);
        recylerView.setHasFixedSize(true);
        recylerView.setLayoutManager(new LinearLayoutManager(this));

        adapter=new MyAdapter(this,listItems);
        recylerView.setAdapter(adapter);
        prepareData();
    }

    private void prepareData()
    {
        ListItem list  = new ListItem(R.drawable.imone,"Mountains");
        listItems.add(list);
        list = new ListItem(R.drawable.imtwo, "Leaves");
        listItems.add(list);
        list = new ListItem(R.drawable.imthree,"Beach");
        listItems.add(list);
        list = new ListItem(R.drawable.imfour,"Trees");
        listItems.add(list);

        adapter.notifyDataSetChanged();
    }
}
